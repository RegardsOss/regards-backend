/**
------------------------------------------------------
FONCTION 	: Fc_IsDisplay
PARAMETRES  	:
  - pRight	: valeur binaire representant le droit d'acces d'un groupe (not null)
  - pMergeRight : valeur binaire representant le droit d'acces fusionne courant (not null)
VALEURS RETOURNEES :
  - droit d'acces (0 ou 1)
DESCRIPTION 	:
  - calcule le droit d'acces a une entite
------------------------------------------------------
*/
FUNCTION Fc_IsDisplay(pRight IN NUMBER, pMergeRight IN NUMBER)
	RETURN NUMBER IS
	aIsDisplay     NUMBER;
BEGIN
        IF (pRight = 1) THEN
           aIsDisplay := 1;
        ELSE
           aIsDisplay := pMergeRight;
        END IF;
	RETURN aIsDisplay;
END Fc_IsDisplay;

/**
------------------------------------------------------
PROCEDURE 	: Pr_MergeGroupRightsByType
PARAMETRES  	:
  - pRequest	: requete renvoyant une liste d'enregistrement de type PG_TYPES.typ_merge_group
  - pGroupId    : le groupe cible
VALEURS RETOURNEES :
  - mise a jour de la table TA_GROUP_RIGHTS pour le groupe cible
DESCRIPTION 	:
  - calcule les droit d'acces du groupe cible en fonction d'une liste de groupe
------------------------------------------------------
*/
PROCEDURE Pr_MergeGroupRightsByType (pRequest		IN VARCHAR2,
                                     pGroupId		IN T_GROUP.GROUP_ID%TYPE) IS
        aEntityId               TA_GROUP_RIGHTS.ENTITY_ID%TYPE;
        tmpEntityId             TA_GROUP_RIGHTS.ENTITY_ID%TYPE;
       	aIsDisplayDescription	TA_GROUP_RIGHTS.IS_DISPLAYED_DESCRIPTION%TYPE;
	aIsDisplayedContent	TA_GROUP_RIGHTS.IS_DISPLAYED_CONTENT%TYPE;
	cr_Records		SYS_REFCURSOR;
        aCpt			NUMBER;
        rec_Right		PG_TYPES.typ_merge_group;
BEGIN

     -- Loop on request cursor
     aEntityId := 0;
     tmpEntityId := 0;
     OPEN cr_Records FOR pRequest;
     LOOP
         FETCH cr_Records INTO rec_Right;
	 EXIT WHEN cr_Records%NOTFOUND;

             -- store current entity id
             tmpEntityId := rec_Right.aEntityId;

             IF aEntityId = 0 THEN
                -- First entity
                aEntityId := tmpEntityId;
                aIsDisplayDescription := rec_Right.aIsDisplayDescription;
                aIsDisplayedContent := rec_Right.aIsDisplayedContent;

             ELSIF aEntityId != tmpEntityId THEN
                -- New entity detected
                -- Insert current entity right ...
		INSERT INTO TA_GROUP_RIGHTS( AGROUP_RIGHTS_ID, ENTITY_ID, GROUP_ID, IS_DISPLAYED_DESCRIPTION, IS_DISPLAYED_CONTENT)
		VALUES ( seq_agroup_rights_id.NEXTVAL, aEntityId, pGroupId, aIsDisplayDescription, aIsDisplayedContent);

                -- and init new one
                aEntityId := tmpEntityId;
                aIsDisplayDescription := rec_Right.aIsDisplayDescription;
                aIsDisplayedContent := rec_Right.aIsDisplayedContent;

             ELSE
                -- Same entity : merge right
                aIsDisplayDescription := Fc_IsDisplay(rec_Right.aIsDisplayDescription, aIsDisplayDescription);
                aIsDisplayedContent := Fc_IsDisplay(rec_Right.aIsDisplayedContent, aIsDisplayedContent);
             END IF;

     END LOOP;
     CLOSE cr_Records;
     
     -- Insert last entity 
     -- If no entity exists (do not insert anything)
     IF aEntityId != 0 THEN
        INSERT INTO TA_GROUP_RIGHTS( AGROUP_RIGHTS_ID, ENTITY_ID, GROUP_ID, IS_DISPLAYED_DESCRIPTION, IS_DISPLAYED_CONTENT)
        VALUES ( seq_agroup_rights_id.NEXTVAL, aEntityId, pGroupId, aIsDisplayDescription, aIsDisplayedContent);
     END IF;

END Pr_MergeGroupRightsByType;

/**
------------------------------------------------------
PROCEDURE 	: Pr_MergeGroupRights
PARAMETRES  	:
  - pGroupList	: liste groupes dont les droits vont etre fusionnes pour obtenir les droits du groupe cible
  - pGroupName  : le groupe cible
VALEURS RETOURNEES :
  - mise a jour de la table TA_GROUP_RIGHTS pour le groupe cible
DESCRIPTION 	:
  - calcule les droit d'acces du groupe cible en fonction d'une liste de groupe
------------------------------------------------------
*/
PROCEDURE Pr_MergeGroupRights (pGroupList		IN STRING_TT,
                               pGroupName		IN T_GROUP.NAME%TYPE) IS
        aGroupId		T_GROUP.GROUP_ID%TYPE;
        request			VARCHAR2(32767);
        requestedGroup		VARCHAR2(32767);
BEGIN
     -- Get group id
     aGroupId	:= PG_PRIVATE.Fc_ReturnGroupId(pGroupName);

     -- Purge all records : only data entities
     -- purge data collection
     delete from TA_GROUP_RIGHTS
     where GROUP_ID = aGroupId 
     and entity_id in (select collection_id from T_COLLECTION where collection_type = PG_CONSTANTS.C_COLL_TYPE_DAT);
     -- purge datasets
     delete from TA_GROUP_RIGHTS
     where GROUP_ID = aGroupId 
     and entity_id in (select data_set_id from T_DATA_SET);
     -- purge dataobjects
     delete from TA_GROUP_RIGHTS
     where GROUP_ID = aGroupId 
     and entity_id in (select data_object_id from T_DATA_OBJECT);

     -- DEFINE new GROUP RIGHTS

     -- Build group list IN criterion
     requestedGroup := '(';
     FOR aCpt IN 1 .. pGroupList.COUNT LOOP
         IF aCpt = 1 THEN
            requestedGroup := requestedGroup || PG_PRIVATE.Fc_ReturnGroupId(pGroupList(aCpt));
         ELSE
             requestedGroup := requestedGroup || ',' || PG_PRIVATE.Fc_ReturnGroupId(pGroupList(aCpt));
         END IF;
     END LOOP;
     requestedGroup := requestedGroup || ')';

     -- MANAGE DATA COLLECTION RIGHTS
     -- Data collection type : PG_CONSTANTS.C_COLL_TYPE_DAT
     request := 'select ENTITY_ID, IS_DISPLAYED_DESCRIPTION, IS_DISPLAYED_CONTENT ' ||
                ' from TA_GROUP_RIGHTS, T_COLLECTION where GROUP_ID IN ' || requestedGroup ||
                ' and entity_id = collection_id and collection_type = ''' || PG_CONSTANTS.C_COLL_TYPE_DAT || '''' ||
                ' order by ENTITY_ID ASC';
     Pr_MergeGroupRightsByType(request, aGroupId);


     -- MANAGE DATASET RIGHTS
     request := 'select ENTITY_ID, IS_DISPLAYED_DESCRIPTION, IS_DISPLAYED_CONTENT ' ||
                ' from TA_GROUP_RIGHTS, T_DATA_SET where GROUP_ID IN ' || requestedGroup ||
                ' and entity_id = data_set_id ' ||
                ' order by ENTITY_ID ASC';
     Pr_MergeGroupRightsByType(request, aGroupId);

     -- MANAGE DATAOBJECT RIGHTS
          request := 'select ENTITY_ID, IS_DISPLAYED_DESCRIPTION, IS_DISPLAYED_CONTENT ' ||
                ' from TA_GROUP_RIGHTS, T_DATA_OBJECT where GROUP_ID IN ' || requestedGroup ||
                ' and entity_id = data_object_id' ||
                ' order by ENTITY_ID ASC';
     Pr_MergeGroupRightsByType(request, aGroupId);

END Pr_MergeGroupRights;

